# myspringcloudvisionplanet

This repository belongs to the following blog post: https://mydeveloperplanet.com/2019/06/19/google-cloud-vision-with-spring-boot/
